//
//  View2Controller.swift
//  LabourSearch
//
//  Created by LIN LIU on 16/11/19.
//  Copyright © 2019 LinLiu. All rights reserved.
//



import UIKit

class View2Controller: UIViewController {
    var view2 = View2()
    var transition1 = Transitions()
    
    
    
    override func loadView() {
        view = view2
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
