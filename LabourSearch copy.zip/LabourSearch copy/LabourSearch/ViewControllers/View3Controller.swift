//
//  View3Controller.swift
//  LabourSearch
//
//  Created by LIN LIU on 16/11/19.
//  Copyright © 2019 LinLiu. All rights reserved.
//




import UIKit

class View3Controller: UIViewController {
    var view3 = View3()
    var transition1 = Transitions()
    
    
    
    override func loadView() {
        view = view3
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
